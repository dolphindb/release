HOST = 'localhost'
PORT = 8080

HOST = '38.124.1.173'
PORT = 8921

