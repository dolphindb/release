package com.xxdb.io;

public interface ProgressListener {
	void progress(String message);
}
