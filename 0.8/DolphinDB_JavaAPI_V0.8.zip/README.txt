DolphinDB Java API V0.8


To use DolphinDB Java API, please add dolphindb.jar to your library path.


1. Mapping between Java Objects and DolphinDB Objects



Java API uses the class interface "Entity" to represent all types of data returned from DolphinDB. You can find individual class names by importing the package of com.xxdb.data in the format of "Basic" + <DataTypeName> + <DataFormName>, where "Basic" indicates the basic implementation of a data type interface, "<DataTypeName>" is a DolphinDB data type name, and "<DataFormName>" is a DolphinDB data form name.


com.xxdb.data.Entity;               // any entity returned from DolphinDB

com.xxdb.data.BasicChart;           // DolphinDB Chart

com.xxdb.data.BasicTable;           // DolphinDB Table

com.xxdb.data.BasicDictionary;      // DolphinDB Dictionary

com.xxdb.data.BasicSet;             // DolphinDB set

com.xxdb.data.BasicAnyVector;       // DolphinDB Tuple

com.xxdb.data.BasicIntVector;          // DolphinDB int vector

com.xxdb.data.BasicIntMatrix;          // DolphinDB int matrix

com.xxdb.data.BasicIntScalar;       // DolphinDB int scalar



Java API supports missing values. Scalar, vector and matrix objects provide the function isNull to check if all elements are missing value and the function setNull to set all elements to be null value.


2. Setup DolphinDB connection


Java API connects to DolphinDB server through TCP/IP protocol. To establish a connection, specify the host and port of the server as illustrated by the example below.


import com.xxdb;

       

DBConnection conn = new DBConnection();

//login as admin; the default admin acount name is "admin" and the default password is "123456"
boolean success = conn.connect("localhost", 8848,"admin","123456");

//noraml login
boolean success = conn.connect("localhost", 8848)



3. Run Scripts



You can use the following statement to run a DolphinDB script. The maximum length of a script is 65,535 bytes.

conn.run("YOUR SCRIPT")


For more details, please refer to 

http://dolphindb.com/help/JavaAPI.html

DolphinDB Team
