﻿namespace dolphindb.io
{

    public interface ProgressListener
    {
        void progress(string message);
    }

}